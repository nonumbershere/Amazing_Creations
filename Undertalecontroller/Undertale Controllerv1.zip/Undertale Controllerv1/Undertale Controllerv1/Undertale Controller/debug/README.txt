This was not made for you, unless your one of our devs. There are no devs. But if you are a developer not from here you may use this as an example. You may not add copyright, because we already added it to every source.bat,


THIS IS FOR DEVELOPERS THAT WANT TO MAKE EXTRA COMMANDS!

Visual Studio is an optional WRITTER.